
package main;

import java.util.ArrayList;
import java.util.Scanner;

public class StoredMessages {

    private ArrayList<Message> messages;

    // Constructor
    public StoredMessages() {
        messages = Message.getStoredMessages();
    }

    // ==========================================
    // NEW METHODS FOR UNIT TESTING
    // ==========================================

    // Add a sent message ID
    public void addSentMessage(String id) {

        if (id != null && !id.trim().isEmpty()) {

            if (!Message.getMessageIDs().contains(id)) {
                Message.getMessageIDs().add(id);
            }
        }
    }

    // Add a disregarded message ID
    public void addDisregardedMessage(String id) {

        if (id != null && !id.trim().isEmpty()) {

            if (!Message.getMessageIDs().contains(id)) {
                Message.getMessageIDs().add(id);
            }
        }
    }

    // Check whether a message ID exists
    public boolean messageIDExists(String id) {

        if (id == null) {
            return false;
        }

        for (Message m : messages) {

            if (id.equals(m.getMessageID())) {
                return true;
            }
        }

        return Message.getMessageIDs().contains(id);
    }

    // Add a stored message
    public void addStoredMessage(
            String id,
            String hash,
            String message,
            String sender,
            String recipient) {

        if (id == null || hash == null
                || message == null || sender == null
                || recipient == null) {

            throw new IllegalArgumentException(
                    "Message details cannot be null.");
        }

        if (messageIDExists(id)) {

            throw new IllegalArgumentException(
                    "Message ID already exists.");
        }

        Message newMessage = new Message(
                id,
                messages.size() + 1,
                sender,
                recipient,
                message
        );

        // Set the supplied message hash
        newMessage.setMessageHash(hash);

        // Set message status
        newMessage.setMessageStatus("Stored");

        // Add message to stored messages
        messages.add(newMessage);

        // Save messages to JSON
        if (!Message.storeMessages()) {

            messages.remove(newMessage);

            throw new IllegalStateException(
                    "Could not save message to JSON.");
        }
    }

    // ==========================================
    // EXISTING STORED MESSAGES MENU
    // ==========================================

    public void showStoredMessagesMenu(Scanner input) {

        int option = 0;

        while (option != 7) {

            System.out.println("\n===== STORED MESSAGES MENU =====");
            System.out.println("1. Display all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search for a message by ID");
            System.out.println("4. Search for messages by recipient");
            System.out.println("5. Delete a message using its hash");
            System.out.println("6. Display the stored messages report");
            System.out.println("7. Returning to main menu...");
            System.out.print("Choose an option (1-7): ");

            if (input.hasNextInt()) {

                option = input.nextInt();
                input.nextLine();

                if (option == 7) {

                    System.out.println("Returning to main menu...");
                    return;
                }

                validateMenuOption(option, input);

            } else {

                System.out.println(
                        "Invalid input. Please enter a number.");

                input.nextLine();
            }
        }
    }

    // Validate menu option
    private void validateMenuOption(int option, Scanner input) {

        switch (option) {

            case 1:
                displayStoredSendersAndRecipients();
                break;

            case 2:
                getLongestStoredMessage();
                break;

            case 3:
                searchByMessageID(input);
                break;

            case 4:
                searchByRecipient(input);
                break;

            case 5:
                deleteByMessageHash(input);
                break;

            case 6:
                generateReport();
                break;

            case 7:
                System.out.println("Returning to main menu...");
                return;

            default:
                System.out.println(
                        "Invalid option. Choose from 1 to 7.");
        }
    }

    // OPTION 1: Display all stored messages
    private void displayStoredSendersAndRecipients() {

        if (messages.isEmpty()) {

            System.out.println("There are no stored messages.");
            return;
        }

        for (Message m : messages) {

            System.out.println("\nMessage ID: "
                    + m.getMessageID());

            System.out.println("Sender: "
                    + m.getSender());

            System.out.println("Recipient: "
                    + m.getRecipient());

            System.out.println("Message: "
                    + m.getMessage());

            System.out.println("Hash: "
                    + m.getMessageHash());
        }
    }

    // OPTION 2: Display the longest stored message
    private void getLongestStoredMessage() {

        if (messages.isEmpty()) {

            System.out.println("There are no stored messages.");
            return;
        }

        Message longest = messages.get(0);

        for (Message m : messages) {

            if (m.getMessage().length()
                    > longest.getMessage().length()) {

                longest = m;
            }
        }

        System.out.println("\nLongest stored message:");

        System.out.println("Message ID: "
                + longest.getMessageID());

        System.out.println("Message: "
                + longest.getMessage());

        System.out.println("Length: "
                + longest.getMessage().length()
                + " characters");
    }

    // OPTION 3: Search by message ID
    private void searchByMessageID(Scanner input) {

        System.out.print("Enter the message ID: ");

        String searchID = input.nextLine().trim();

        boolean found = false;

        for (Message m : messages) {

            if (m.getMessageID().equalsIgnoreCase(searchID)) {

                System.out.println("\nMessage found!");

                System.out.println("Sender: " + m.getSender());
                System.out.println("Recipient: " + m.getRecipient());
                System.out.println("Message: " + m.getMessage());
                System.out.println("Hash: " + m.getMessageHash());

                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("No message found with that ID.");
        }
    }

    // OPTION 4: Search by recipient
    private void searchByRecipient(Scanner input) {

        System.out.print("Enter the recipient: ");

        String searchRecipient = input.nextLine().trim();

        boolean found = false;

        for (Message m : messages) {

            if (m.getRecipient().equalsIgnoreCase(searchRecipient)) {

                System.out.println("\nMessage found!");

                System.out.println("Message ID: "
                        + m.getMessageID());

                System.out.println("Sender: "
                        + m.getSender());

                System.out.println("Recipient: "
                        + m.getRecipient());

                System.out.println("Message: "
                        + m.getMessage());

                found = true;
            }
        }

        if (!found) {
            System.out.println(
                    "No messages found for that recipient.");
        }
    }

    // OPTION 5: Delete a message using its hash
    private void deleteByMessageHash(Scanner input) {

        System.out.print("Enter the message hash to delete: ");

        String searchHash = input.nextLine().trim();

        Message foundMessage = null;

        for (Message m : messages) {

            if (m.getMessageHash().equals(searchHash)) {

                foundMessage = m;
                break;
            }
        }

        if (foundMessage == null) {

            System.out.println(
                    "No message found with that hash.");

            return;
        }

        messages.remove(foundMessage);

        if (Message.storeMessages()) {

            System.out.println(
                    "Message deleted successfully.");

        } else {

            messages.add(foundMessage);

            System.out.println(
                    "Could not update JSON file. "
                    + "Message deletion was cancelled.");
        }
    }

    // OPTION 6: Generate stored messages report
    private void generateReport() {

        System.out.println(
                "\n===== STORED MESSAGES REPORT =====");

        System.out.println(
                "Total stored messages: " + messages.size());

        if (messages.isEmpty()) {

            System.out.println(
                    "No stored messages to report.");

            return;
        }

        for (int i = 0; i < messages.size(); i++) {

            Message m = messages.get(i);

            System.out.println("\nMessage " + (i + 1));

            System.out.println("ID: "
                    + m.getMessageID());

            System.out.println("Hash: "
                    + m.getMessageHash());

            System.out.println("Sender: "
                    + m.getSender());

            System.out.println("Recipient: "
                    + m.getRecipient());

            System.out.println("Message: "
                    + m.getMessage());
        }
    }
}
