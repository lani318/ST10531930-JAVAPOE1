

package main;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Message {

    private String messageID;
    private int messageNumber;
    private String sender;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus = "Not sent";

    private static final String JSON_FILE = "messages.json";

    // Required message collections
    private static final ArrayList<Message> sentMessages =
            new ArrayList<>();

    private static final ArrayList<Message> disregardedMessages =
            new ArrayList<>();

    private static final ArrayList<Message> storedMessages =
            new ArrayList<>();

    // Message ID and hash collections
    private static final ArrayList<String> messageIDs =
            new ArrayList<>();

    private static final ArrayList<String> messageHashes =
            new ArrayList<>();

    private static final Set<String> usedMessageIDs =
            new HashSet<>();

    private static final Random random = new Random();

    private static int totalMessages = 0;
    private static int messageCounter = 0;
    private static int messagesProcessed = 0;
    private static int maximumMessages = 0;

    // Constructor
    public Message(String messageID, int messageNumber,
                   String sender, String recipient, String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();

        if (!messageIDs.contains(messageID)) {
            messageIDs.add(messageID);
        }

        if (!messageHashes.contains(messageHash)) {
            messageHashes.add(messageHash);
        }
    }

    // Compatibility constructor
    public Message(String messageID, int messageNumber,
                   String recipient, String message) {

        this(messageID, messageNumber, "Unknown",
                recipient, message);
    }

    // Generate a unique message ID
    public static String generateMessageID() {

        String id;

        do {
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < 10; i++) {
                builder.append(random.nextInt(10));
            }

            id = builder.toString();

        } while (usedMessageIDs.contains(id));

        usedMessageIDs.add(id);
        return id;
    }

    // Check message ID
    public boolean checkMessageID() {
        return messageID != null
                && messageID.matches("\\d{10}");
    }

    // Check recipient cellphone number
    public boolean checkRecipientCell() {
        return recipient != null
                && recipient.matches("\\+\\d{9,12}");
    }

    // Create message hash
    public final String createMessageHash() {

        String firstTwo = "00";

        if (messageID != null && messageID.length() >= 2) {
            firstTwo = messageID.substring(0, 2);
        }

        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {

            String[] words = message.trim().split("\\s+");

            firstWord = words[0];
            lastWord = words[words.length - 1];
        }

        return (firstTwo + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    // Setters
    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }

    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageStatus() {
        return messageStatus;
    }

    public static ArrayList<Message> getSentMessages() {
        return sentMessages;
    }

    public static ArrayList<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    // Required by StoredMessages.java
    public static ArrayList<Message> getStoredMessages() {
        return storedMessages;
    }

    public static ArrayList<String> getMessageIDs() {
        return messageIDs;
    }

    public static ArrayList<String> getMessageHashes() {
        return messageHashes;
    }

    // Send, disregard or store a message
    public String SentMessage(Scanner input) {

        while (true) {

            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");
            System.out.print("Choose an option: ");

            String choice = input.nextLine().trim();

            switch (choice) {

                case "1":
                    messageStatus = "Sent";
                    sentMessages.add(this);
                    totalMessages++;

                    return "Message successfully sent";

                case "2":
                    messageStatus = "Disregarded";
                    disregardedMessages.add(this);

                    System.out.println("Message disregarded.");
                    return "Message deleted.";

                case "3":
                    messageStatus = "Stored";
                    storedMessages.add(this);

                    if (storeMessages()) {
                        return "Message successfully stored";
                    }

                    storedMessages.remove(this);
                    messageStatus = "Not sent";

                    return "Could not save message to the file.";

                default:
                    System.out.println(
                            "Invalid option. Please select 1, 2 or 3.");
            }
        }
    }

    // JSON STORAGE METHODS

    // Save stored messages to JSON
    public static boolean storeMessages() {

        JSONArray array = new JSONArray();

        for (Message m : storedMessages) {

            JSONObject object = new JSONObject();

            object.put("messageID", m.messageID);
            object.put("messageNumber", m.messageNumber);
            object.put("sender", m.sender);
            object.put("recipient", m.recipient);
            object.put("message", m.message);
            object.put("messageHash", m.messageHash);
            object.put("messageStatus", m.messageStatus);

            array.add(object);
        }

        try (FileWriter writer = new FileWriter(JSON_FILE)) {

            writer.write(array.toJSONString());
            writer.flush();

            return true;

        } catch (IOException e) {

            System.out.println(
                    "JSON saving error: " + e.getMessage());

            return false;
        }
    }

    // Load stored messages from JSON
    public static void loadStoredMessagesFromJSON() {
       
    storedMessages.clear();
    messageIDs.clear();
    messageHashes.clear();
    usedMessageIDs.clear();

        storedMessages.clear();

        File file = new File(JSON_FILE);

        if (!file.exists()) {
            return;
        }

        try (FileReader reader = new FileReader(file)) {

            JSONParser parser = new JSONParser();
            Object data = parser.parse(reader);

            if (!(data instanceof JSONArray)) {

                System.out.println(
                        "Invalid JSON format in messages.json.");

                return;
            }

            JSONArray array = (JSONArray) data;

            for (Object item : array) {

                if (!(item instanceof JSONObject)) {
                    continue;
                }

                JSONObject object = (JSONObject) item;

                String id = (String) object.get("messageID");
                String sender = (String) object.get("sender");
                String recipient = (String) object.get("recipient");
                String messageText = (String) object.get("message");
                String hash = (String) object.get("messageHash");

                Object numberValue = object.get("messageNumber");

                // Skip incomplete records
                if (id == null || sender == null
                        || recipient == null || messageText == null
                        || numberValue == null) {

                    continue;
                }

                int number = ((Number) numberValue).intValue();

                Message m = new Message(
                        id, number, sender, recipient, messageText);

                if (hash != null) {
                    m.messageHash = hash;
                }

                Object statusValue = object.get("messageStatus");

                m.messageStatus = statusValue == null
                        ? "Stored" : statusValue.toString();

                storedMessages.add(m);

                usedMessageIDs.add(id);
            }

        } catch (IOException | ParseException e) {

            System.out.println(
                    "Could not load stored messages: "
                    + e.getMessage());

        } catch (ClassCastException e) {

            System.out.println(
                    "Invalid message data in JSON file.");
        }
    }

    // END OF JSON STORAGE METHODS

    public static int returnTotalMessages() {
        return totalMessages;
    }

    public static void printMessages() {
        System.out.println("Coming Soon.");
    }

    // Display message details
    private void displayMessageDetails() {

        System.out.println("Message ID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Sender: " + sender);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
    }

    // Start QuickChat after successful login
    public static void startQuickChat(Scanner input, String sender) {

        // Load stored messages from JSON
        loadStoredMessagesFromJSON();

        System.out.println("\nWelcome to QuickChat.");

        while (maximumMessages < 1) {

            System.out.print(
                    "How many messages would you like to enter? ");

            try {

                maximumMessages =
                        Integer.parseInt(input.nextLine().trim());

                if (maximumMessages < 1) {

                    System.out.println(
                            "Enter a whole number greater than zero.");
                }

            } catch (NumberFormatException e) {

                maximumMessages = 0;

                System.out.println(
                        "Please enter a valid whole number.");
            }
        }

        boolean running = true;

        while (running) {

            System.out.println("\nQUICKCHAT MENU");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose an option: ");

            String option = input.nextLine().trim();

            switch (option) {

                case "1":

                    if (messagesProcessed >= maximumMessages) {

                        System.out.println(
                                "You have entered all "
                                + maximumMessages + " messages.");

                    } else {

                        sendMessages(input,
                                maximumMessages - messagesProcessed,
                                sender);
                    }

                    break;

                case "2":
                    printMessages();
                    break;

                case "3":

                    running = false;

                    System.out.println(
                            "Thank you for using QuickChat.");

                    System.out.println(
                            "Total messages sent: " + totalMessages);

                    break;

                case "4":

                    StoredMessages storedMenu =
                            new StoredMessages();

                    storedMenu.showStoredMessagesMenu(input);

                    break;

                default:

                    System.out.println(
                            "Invalid option. Select 1, 2, 3 or 4.");
            }
        }
    }

    // Compatibility method for older calls
    public static void startQuickChat(Scanner input) {
        startQuickChat(input, "Unknown");
    }

    // Send messages
    public static void sendMessages(
            Scanner input, int numberOfMessages, String sender) {

        for (int i = 0;
             i < numberOfMessages
             && messagesProcessed < maximumMessages;
             i++) {

            messageCounter++;

            System.out.println("\nMESSAGE " + messageCounter);

            String messageID = generateMessageID();

            System.out.println("Message ID: " + messageID);

            String recipient;

            while (true) {

                System.out.print(
                        "Enter recipient cellphone number "
                        + "(e.g. +27838968976): ");

                recipient = input.nextLine().trim();

                Message temporary = new Message(
                        messageID, messageCounter, sender,
                        recipient, "Test");

                if (temporary.checkRecipientCell()) {

                    System.out.println(
                            "Cell phone number successfully captured.");

                    break;
                }

                System.out.println(
                        "Invalid number. Enter + followed by "
                        + "9 to 12 digits.");
            }

            String messageText;

            while (true) {

                System.out.print("Enter your message: ");

                messageText = input.nextLine();

                if (messageText.trim().isEmpty()) {

                    System.out.println(
                            "The message cannot be empty.");

                } else if (messageText.length() >= 250) {

                    System.out.println(
                            "Please enter a message of less than "
                            + "250 characters.");

                } else {

                    break;
                }
            }

            Message newMessage = new Message(
                    messageID, messageCounter, sender,
                    recipient, messageText);

            System.out.println(
                    "Message Hash: " + newMessage.messageHash);

            System.out.println(newMessage.SentMessage(input));

            if ("Sent".equals(newMessage.messageStatus)) {
                newMessage.displayMessageDetails();
            }

            messagesProcessed++;
        }

        System.out.println("\nMessages processed: "
                + messagesProcessed + " of " + maximumMessages);

        System.out.println("Total messages sent: " + totalMessages);
    }
}