package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login userLogin = new Login();

        System.out.println("=== REGISTRATION ===");

        System.out.println("Enter first name:");
        userLogin.setFirstName(input.nextLine());

        System.out.println("Enter last name:");
        userLogin.setLastName(input.nextLine());

        String username;
        while (true) {
            System.out.println("Enter username:");
            username = input.nextLine();

            if (userLogin.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password;
        while (true) {
            System.out.println("Enter password:");
            password = input.nextLine();

            if (userLogin.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cellPhone;
        while (true) {
            System.out.println("Enter cell phone number (e.g. +27838968976):");
            cellPhone = input.nextLine();

            if (userLogin.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        }

        System.out.println(userLogin.registerUser(username, password));

        System.out.println("\n=== LOGIN ===");

        while (true) {
            System.out.println("Enter username:");
            String enteredUsername = input.nextLine();

            System.out.println("Enter password:");
            String enteredPassword = input.nextLine();

            boolean loginSuccess = userLogin.loginUser(enteredUsername, enteredPassword);
            System.out.println(userLogin.returnLoginStatus(loginSuccess));

            if (loginSuccess) {
                break;
            }
        }

        input.close();
    }
}