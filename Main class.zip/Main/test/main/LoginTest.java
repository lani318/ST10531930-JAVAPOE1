package main;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testSetFirstNameAndLastName() {
        login.setFirstName("Kylie");
        login.setLastName("Jenner");
        
        String expected = "Welcome Kylie, Jenner it is great to see you again.";
        String actual = login.returnLoginStatus(true);
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckUserNameValid() {
        // Valid username: contains '_' and length <= 5
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserNameInvalidFormat() {
        // Invalid: missing underscore '_'
        assertFalse(login.checkUserName("kylie"));
    }

    @Test
    public void testCheckUserNameTooLong() {
        // Invalid: contains '_' but length > 5
        assertFalse(login.checkUserName("k_ylie"));
    }

    @Test
    public void testCheckPasswordComplexitySuccess() {
        // Valid: >= 8 chars, uppercase letter, number, special char
        assertTrue(login.checkPasswordComplexity("Ch33s3s*"));
    }

    @Test
    public void testCheckPasswordComplexityFailure() {
        // Invalid: missing uppercase, digits, and special characters
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumberValid() {
        // Valid: starts with +27 followed by 10 or fewer digits
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumberInvalidPrefix() {
        // Invalid: does not start with +27
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testCheckCellPhoneNumberTooLong() {
        // Invalid: digit string length exceeds 10 digits
        assertFalse(login.checkCellPhoneNumber("+2712345678901"));
    }

    @Test
    public void testRegisterUserSuccess() {
        String expected = "The two above conditions have been met, and the user has been registered successfully.";
        String actual = login.registerUser("kyl_1", "Ch33s3s*");
        assertEquals(expected, actual);
    }

    @Test
    public void testRegisterUserInvalidUsername() {
        String expected = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        String actual = login.registerUser("kylie", "Ch33s3s*");
        assertEquals(expected, actual);
    }

    @Test
    public void testRegisterUserInvalidPassword() {
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        String actual = login.registerUser("kyl_1", "password");
        assertEquals(expected, actual);
    }

    @Test
    public void testLoginUserSuccess() {
        login.registerUser("kyl_1", "Ch33s3s*");
        assertTrue(login.loginUser("kyl_1", "Ch33s3s*"));
    }

    @Test
    public void testLoginUserFailure() {
        login.registerUser("kyl_1", "Ch33s3s*");
        assertFalse(login.loginUser("kyl_1", "WrongPass1!"));
    }

    @Test
    public void testLoginUserWithoutRegistration() {
        // Attempting to log in prior to calling registerUser()
        assertFalse(login.loginUser("kyl_1", "Ch33s3s*"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        login.setFirstName("Kylie");
        login.setLastName("Jenner");
        
        String expected = "Welcome Kylie, Jenner it is great to see you again.";
        String actual = login.returnLoginStatus(true);
        assertEquals(expected, actual);
    }

    @Test
    public void testReturnLoginStatusFailure() {
        String expected = "Username or password incorrect, please try again.";
        String actual = login.returnLoginStatus(false);
        assertEquals(expected, actual);
    }
}