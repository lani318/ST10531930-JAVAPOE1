

package main;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus = "Not sent";

    private static final ArrayList<Message> sentMessages =
            new ArrayList<>();

    private static final ArrayList<Message> storedMessages =
            new ArrayList<>();

    private static final Set<String> usedMessageIDs =
            new HashSet<>();

    private static final Random random = new Random();

    private static int totalMessages = 0;
    private static int messageCounter = 0;
    private static int messagesProcessed = 0;
    private static int maximumMessages = 0;

    public Message(String messageID, int messageNumber,
                   String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    public static String generateMessageID() {
        String id;

        do {
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < 10; i++) {
                builder.append(random.nextInt(10));
            }

            id = builder.toString();
        } while (usedMessageIDs.contains(id));

        usedMessageIDs.add(id);
        return id;
    }

    public boolean checkMessageID() {
        return messageID != null
                && messageID.matches("\\d{10}");
    }

    public boolean checkRecipientCell() {
        return recipient != null
                && recipient.matches("\\+\\d{9,12}");
    }

    public final String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {
            String[] words = message.trim().split("\\s+");
            firstWord = words[0];
            lastWord = words[words.length - 1];
        }

        return (firstTwo + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(Scanner input) {
        while (true) {
            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");
            System.out.print("Choose an option: ");

            String choice = input.nextLine().trim();

            switch (choice) {
                case "1":
                    messageStatus = "Sent";
                    sentMessages.add(this);
                    totalMessages++;
                    return "Message successfully sent";

                case "2":
                    System.out.println("Press 0 to delete the message.");
                    System.out.print("Enter 0 to confirm: ");

                    if (input.nextLine().trim().equals("0")) {
                        messageStatus = "Disregarded";
                        return "Message deleted.";
                    }

                    messageStatus = "Disregarded";
                    return "Message disregarded.";

                case "3":
                    messageStatus = "Stored";
                    storedMessages.add(this);

                    if (storeMessages()) {
                        return "Message successfully stored";
                    }

                    storedMessages.remove(this);
                    messageStatus = "Not sent";
                    return "Could not save message to the file.";

                default:
                    System.out.println(
                            "Invalid option. Please select 1, 2 or 3.");
            }
        }
    }

    // Save all stored messages to a JSON file.
    private static boolean storeMessages() {
        try (FileWriter writer = new FileWriter("messages.json")) {
            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {
                Message m = storedMessages.get(i);

                writer.write("  {\n");
                writer.write("    \"messageID\": \""
                        + escape(m.messageID) + "\",\n");
                writer.write("    \"messageNumber\": "
                        + m.messageNumber + ",\n");
                writer.write("    \"recipient\": \""
                        + escape(m.recipient) + "\",\n");
                writer.write("    \"message\": \""
                        + escape(m.message) + "\",\n");
                writer.write("    \"messageHash\": \""
                        + escape(m.messageHash) + "\",\n");
                writer.write("    \"messageStatus\": \""
                        + escape(m.messageStatus) + "\"\n");
                writer.write("  }");

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]\n");
            return true;

        } catch (IOException e) {
            System.out.println(
                    "Could not save message: " + e.getMessage());
            return false;
        }
    }

    private static String escape(String text) {
        if (text == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            switch (c) {
                case '"':
                    result.append("\\\"");
                    break;
                case '\\':
                    result.append("\\\\");
                    break;
                case '\b':
                    result.append("\\b");
                    break;
                case '\f':
                    result.append("\\f");
                    break;
                case '\n':
                    result.append("\\n");
                    break;
                case '\r':
                    result.append("\\r");
                    break;
                case '\t':
                    result.append("\\t");
                    break;
                default:
                    if (c < 0x20) {
                        result.append(String.format(
                                "\\u%04x", (int) c));
                    } else {
                        result.append(c);
                    }
            }
        }

        return result.toString();
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Assignment requirement: option 2 displays Coming Soon.
    public static void printMessages() {
        System.out.println("Coming Soon.");
    }

    private void displayMessageDetails() {
        System.out.println("Message ID: " + messageID);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + message);
    }

    // Called from Main.java only after successful login.
    public static void startQuickChat(Scanner input) {
        System.out.println("\nWelcome to QuickChat.");

        while (maximumMessages < 1) {
            System.out.print(
                    "How many messages would you like to enter? ");

            try {
                maximumMessages =
                        Integer.parseInt(input.nextLine().trim());

                if (maximumMessages < 1) {
                    System.out.println(
                            "Enter a whole number greater than zero.");
                }
            } catch (NumberFormatException e) {
                maximumMessages = 0;
                System.out.println(
                        "Please enter a valid whole number.");
            }
        }

        boolean running = true;

        while (running) {
            System.out.println("\nQUICKCHAT MENU");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Choose an option: ");

            String option = input.nextLine().trim();

            switch (option) {
                case "1":
                    if (messagesProcessed >= maximumMessages) {
                        System.out.println(
                                "You have entered all "
                                + maximumMessages + " messages.");
                    } else {
                        sendMessages(input,
                                maximumMessages - messagesProcessed);
                    }
                    break;

                case "2":
                    printMessages();
                    break;

                case "3":
                    running = false;
                    System.out.println(
                            "Thank you for using QuickChat.");
                    System.out.println(
                            "Total messages sent: " + totalMessages);
                    break;

                default:
                    System.out.println(
                            "Invalid option. Select 1, 2 or 3.");
            }
        }
    }

    public static void sendMessages(
            Scanner input, int numberOfMessages) {

        for (int i = 0;
             i < numberOfMessages
                     && messagesProcessed < maximumMessages;
             i++) {

            messageCounter++;

            System.out.println("\nMESSAGE " + messageCounter);

            String messageID = generateMessageID();
            System.out.println("Message ID: " + messageID);

            String recipient;

            while (true) {
                System.out.print(
                        "Enter recipient cellphone number "
                        + "(e.g. +27838968976): ");

                recipient = input.nextLine().trim();

                Message temporary = new Message(
                        messageID, messageCounter, recipient, "Test");

                if (temporary.checkRecipientCell()) {
                    System.out.println(
                            "Cell phone number successfully captured.");
                    break;
                }

                System.out.println(
                        "Invalid number. Enter + followed by "
                        + "9 to 12 digits.");
            }

            String messageText;

            while (true) {
                System.out.print("Enter your message: ");
                messageText = input.nextLine();

                if (messageText.trim().isEmpty()) {
                    System.out.println(
                            "The message cannot be empty.");
                } else if (messageText.length() >= 250) {
                    System.out.println(
                            "Please enter a message of less than "
                            + "250 characters.");
                } else {
                    break;
                }
            }

            Message newMessage = new Message(
                    messageID, messageCounter, recipient, messageText);

            System.out.println(
                    "Message Hash: " + newMessage.messageHash);

            System.out.println(newMessage.SentMessage(input));

            if ("Sent".equals(newMessage.messageStatus)) {
                newMessage.displayMessageDetails();
            }

            messagesProcessed++;
        }

        System.out.println("\nMessages processed: "
                + messagesProcessed + " of " + maximumMessages);
        System.out.println("Total messages sent: " + totalMessages);
    }
}
