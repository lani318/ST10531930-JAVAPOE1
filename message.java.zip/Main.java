
package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login userLogin = new Login();

        System.out.println("================================");
        System.out.println("       QUICKCHAT REGISTER");
        System.out.println("================================");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine().trim();
        userLogin.setFirstName(firstName);

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine().trim();
        userLogin.setLastName(lastName);

        String username;

        while (true) {
            System.out.print("Create a username (must contain _ and be no more than 5 characters): ");
            username = input.nextLine().trim();

            if (userLogin.checkUserName(username)) {
                break;
            }

            System.out.println(
                "Username is not correctly formatted. "
                + "Please include an underscore and use no more than 5 characters."
            );
        }

        String password;

        while (true) {
            System.out.print("Create a password: ");
            password = input.nextLine();

            if (userLogin.checkPasswordComplexity(password)) {
                break;
            }

            System.out.println(
                "Password must have at least 8 characters, "
                + "a capital letter, a number and a special character."
            );
        }

        String cellPhone;

        while (true) {
            System.out.print("Enter your South African cellphone number (e.g. +27831234567): ");
            cellPhone = input.nextLine().trim();

            if (userLogin.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cellphone number successfully captured.");
                break;
            }

            System.out.println(
                "Invalid cellphone number. Use +27 followed by 9 digits."
            );
        }

        System.out.println("\n" + userLogin.registerUser(username, password));

        System.out.println("\n================================");
        System.out.println("          QUICKCHAT LOGIN");
        System.out.println("================================");

        boolean loginSuccess = false;

        while (!loginSuccess) {

            System.out.print("Enter your username: ");
            String enteredUsername = input.nextLine().trim();

            System.out.print("Enter your password: ");
            String enteredPassword = input.nextLine();

            loginSuccess = userLogin.loginUser(
                enteredUsername,
                enteredPassword
            );

            System.out.println(
                userLogin.returnLoginStatus(loginSuccess)
            );

            if (!loginSuccess) {
                System.out.println("Please try logging in again.\n");
            }
        }

        // LINK Main.java TO THE QUICKCHAT CLASS.
        // QuickChat only starts after a successful login.
        Message.startQuickChat(input);

        input.close();
    }
}
